
<template>
  <h1>Welcome to the Idiot Quiz</h1>
  <p>This is just a placeholder for the actual app.</p>
</template>

<script>
export default {
  name: 'App'
}
</script>
